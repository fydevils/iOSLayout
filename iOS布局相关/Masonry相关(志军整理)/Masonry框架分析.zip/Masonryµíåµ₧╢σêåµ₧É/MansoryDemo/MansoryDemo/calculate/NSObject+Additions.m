//
//  NSObject+Additions.m
//  链式编程
//
//  Created by 岑志军 on 2019/4/24.
//  Copyright © 2019 岑志军. All rights reserved.
//

#import "NSObject+Additions.h"

@implementation NSObject (Additions)

- (int)zj_makeCalculate:(void (NS_NOESCAPE ^)(ZJCalCulateMgr * mgr))block{
    
    ZJCalCulateMgr *calculateMgr = [[ZJCalCulateMgr alloc] init];

    block(calculateMgr);
    
    return calculateMgr.result;
}
    
@end
