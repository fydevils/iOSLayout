//
//  NSObject+Additions.h
//  链式编程
//
//  Created by 岑志军 on 2019/4/24.
//  Copyright © 2019 岑志军. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ZJCalCulateMgr.h"

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (Additions)
    
// NS_NOESCAPE用于修饰方法中的block类型参数 作用是告诉编译器，block这个block在zj_makeCalculate:方法返回之前就会执行完毕，而不是被保存起来在之后的某个时候再执行

- (int)zj_makeCalculate:(void (NS_NOESCAPE ^)(ZJCalCulateMgr *mgr))block;

@end

NS_ASSUME_NONNULL_END
