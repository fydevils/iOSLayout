//
//  ZJCalCulateMgr.h
//  链式编程
//
//  Created by 岑志军 on 2019/4/24.
//  Copyright © 2019 岑志军. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZJCalCulateMgr : NSObject
    
@property (nonatomic, assign) int result;

- (ZJCalCulateMgr *(^)(int))add;
- (ZJCalCulateMgr *(^)(int))sub;
- (ZJCalCulateMgr *(^)(int))multiply;
- (ZJCalCulateMgr *(^)(int))divide;

@end

NS_ASSUME_NONNULL_END
