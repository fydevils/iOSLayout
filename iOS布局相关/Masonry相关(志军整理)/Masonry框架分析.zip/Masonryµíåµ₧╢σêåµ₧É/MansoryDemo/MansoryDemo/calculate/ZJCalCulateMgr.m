//
//  ZJCalCulateMgr.m
//  链式编程
//
//  Created by 岑志军 on 2019/4/24.
//  Copyright © 2019 岑志军. All rights reserved.
//

#import "ZJCalCulateMgr.h"

@implementation ZJCalCulateMgr

- (ZJCalCulateMgr * _Nonnull (^)(int))add{
    return ^(int value){
        self.result += value;
        
        return self;
    };
}
    
- (ZJCalCulateMgr * _Nonnull (^)(int))sub{
    return ^(int value){
        self.result -= value;
        
        return self;
    };
}
    
- (ZJCalCulateMgr * _Nonnull (^)(int))multiply{
    return ^(int value){
        self.result *= value;
        
        return self;
    };
}
    
- (ZJCalCulateMgr * _Nonnull (^)(int))divide{
    return ^(int value){
        self.result /= value;
        
        return self;
    };
}
    
@end
