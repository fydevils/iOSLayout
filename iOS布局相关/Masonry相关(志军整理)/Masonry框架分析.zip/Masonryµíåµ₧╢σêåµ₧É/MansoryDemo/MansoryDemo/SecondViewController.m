//
//  SecondViewController.m
//  MansoryDemo
//
//  Created by 岑志军 on 2019/4/26.
//  Copyright © 2019 岑志军. All rights reserved.
//

#import "SecondViewController.h"
#import "UILabel+zjLabel.h"
#import "Masonry.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
    UILabel *label = [UILabel zj_createLabel:^(UILabel * _Nonnull label) {
        label.zj_text(@"haha").zj_font([UIFont systemFontOfSize:24]).zj_textColor(UIColor.redColor);
    }];
    
    [self.view addSubview:label];
    
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view.mas_centerX);
        make.centerY.equalTo(self.view.mas_centerY);
    }];
}

- (void)dealloc{
    NSLog(@"");
}

@end
