//
//  ViewController.m
//  MansoryDemo
//
//  Created by 岑志军 on 2019/4/25.
//  Copyright © 2019 岑志军. All rights reserved.
//

#import "ViewController.h"
//#define MAS_SHORTHAND_GLOBALS
#import "Masonry.h"
#import "NSObject+Additions.h"
#import "UILabel+zjLabel.h"
#import "SecondViewController.h"

@interface ViewController ()
    
    @end

@implementation ViewController
    
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    UIView *superview = self.view;
    
    UIView *view1 = [[UIView alloc] init];
    view1.translatesAutoresizingMaskIntoConstraints = NO;
    view1.backgroundColor = [UIColor greenColor];
    [superview addSubview:view1];
    
    UIEdgeInsets padding = UIEdgeInsetsMake(10, 10, 10, 10);
    
    
    
//    [superview addConstraints:@[
//
//                                //view1 constraints
//                                [NSLayoutConstraint constraintWithItem:view1
//                                                             attribute:NSLayoutAttributeTop
//                                                         relatedBy:NSLayoutRelationEqual
//                                                            toItem:superview
//                                                         attribute:NSLayoutAttributeTop
//                                                        multiplier:1.0
//                                                          constant:padding.top],
//
//                            [NSLayoutConstraint constraintWithItem:view1
//                                                         attribute:NSLayoutAttributeLeft
//                                                         relatedBy:NSLayoutRelationEqual
//                                                            toItem:superview
//                                                         attribute:NSLayoutAttributeLeft
//                                                        multiplier:1.0
//                                                          constant:padding.left],
//
//                            [NSLayoutConstraint constraintWithItem:view1
//                                                         attribute:NSLayoutAttributeBottom
//                                                         relatedBy:NSLayoutRelationEqual
//                                                            toItem:superview
//                                                         attribute:NSLayoutAttributeBottom
//                                                        multiplier:1.0
//                                                          constant:-padding.bottom],
//
//                            [NSLayoutConstraint constraintWithItem:view1
//                                                         attribute:NSLayoutAttributeRight
//                                                         relatedBy:NSLayoutRelationEqual
//                                                            toItem:superview
//                                                         attribute:NSLayoutAttributeRight
//                                                        multiplier:1
//                                                          constant:-padding.right],
//
//                            ]];
    
    [view1 mas_makeConstraints:^(MASConstraintMaker *make) {
          make.edges.mas_equalTo(superview).with.insets(padding);
    }];
    
    int result = [self zj_makeCalculate:^(ZJCalCulateMgr * _Nonnull mgr) {
                    mgr.add(5).sub(2).multiply(5).divide(2);
                 }];
    
    
    UILabel *label = [UILabel zj_createLabel:^(UILabel * _Nonnull label) {
        label.zj_text(@"haha").zj_font([UIFont systemFontOfSize:24]).zj_textColor(UIColor.redColor);
    }];
    
    [superview addSubview:label];
    
    
//    int (^Ballala)(ZJCalCulateMgr *mgr) = ^int(ZJCalCulateMgr *mgr){
//        mgr.add(5).sub(2).multiply(5).divide(2);
//
//        return mgr.result;
//    };
//
//    Ballala([[ZJCalCulateMgr alloc] init]);
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(view1.mas_centerX);
        make.centerY.equalTo(view1.mas_centerY);
    }];
    
    NSLog(@"=======%d", result);
}

- (IBAction)btnClicked:(id)sender {
    [self.navigationController pushViewController:[[SecondViewController alloc] init] animated:YES];
}
    
@end
