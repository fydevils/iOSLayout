//
//  UILabel+zjLabel.m
//  MansoryDemo
//
//  Created by 岑志军 on 2019/4/26.
//  Copyright © 2019 岑志军. All rights reserved.
//

#import "UILabel+zjLabel.h"

@implementation UILabel (zjLabel)

+ (UILabel *)zj_createLabel:(void (^)(UILabel * _Nonnull))block{
    UILabel *label = [UILabel new];
    block(label);
    return label;
}
    
- (UILabel *(^)(NSString *))zj_text{
    return ^(NSString *str){
        self.text = str;
        
        return self;
    };
}
    
- (UILabel *(^)(UIFont *))zj_font{
    return ^(UIFont *font){
        self.font = font;
        return self;
    };
}
    
- (UILabel *(^)(UIColor *))zj_textColor{
    return ^(UIColor *color){
        self.textColor = color;
        return self;
    };
}
 
- (UILabel *(^)(NSTextAlignment))zj_textAlignment{
    return ^(NSTextAlignment aligment){
        self.textAlignment = aligment;
        return self;
    };
}

    
@end
