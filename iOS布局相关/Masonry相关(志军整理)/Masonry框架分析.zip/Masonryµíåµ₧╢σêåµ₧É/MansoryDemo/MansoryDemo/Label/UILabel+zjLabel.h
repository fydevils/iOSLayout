//
//  UILabel+zjLabel.h
//  MansoryDemo
//
//  Created by 岑志军 on 2019/4/26.
//  Copyright © 2019 岑志军. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UILabel (zjLabel)
    
+ (UILabel *)zj_createLabel:(void(^)(UILabel *label))block;
    
- (UILabel *(^)(NSString *))zj_text;
- (UILabel *(^)(UIFont *))zj_font;
- (UILabel *(^)(UIColor *))zj_textColor;
- (UILabel *(^)(NSTextAlignment))zj_textAlignment;

@end

NS_ASSUME_NONNULL_END
